import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv("./Resources/CSV/complaints.csv", sep=";", encoding="latin-1")

complaints = data["ComplaintSubtheme_EN"]

complaintDict = {}
xLabels = []
yLabels = []

for complaint in complaints:
    value = complaintDict.get(complaint, 1)
    if complaint in complaintDict:
        value += 1
        complaintDict[complaint] = value
    else:
        complaintDict[complaint] = value

for key in complaintDict:
    xLabels.append(key)
    yLabels.append(complaintDict[key])

plt.bar(xLabels, yLabels, color = 'g', align="center", width = 0.3, label = "Topic")
plt.xticks(rotation = 30)
plt.title('Complaint count according to topics')
plt.legend()
plt.show()