import pandas as pd
import pm4py as pm

dataframe = pd.read_csv("./Resources/CSV/complaints.csv", sep=";", encoding="latin-1")

dataframe = pm.format_dataframe(dataframe, case_id="ComplaintSubthemeID", activity_key="ComplaintSubtheme_EN", timestamp_key="ContactDate")

event_log = pm.convert_to_event_log(dataframe)

dfg, start_activities, end_activities = pm.discover_dfg(event_log)

pm.view_dfg(dfg, start_activities, end_activities)