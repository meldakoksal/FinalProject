import pandas as pd

fields = ["ComplaintSubtheme_EN", "ComplaintTopic_EN"]

data = pd.read_csv("./Resources/CSV/complaints.csv", sep=";", encoding="latin-1", usecols=fields)

#pd.set_option('display.max_rows', data.shape[0]+1)

data.to_excel("complaints.xlsx", sheet_name="ComplaintTopic", index=False)